# JARVIS AI v2 — Personal Assistant (Android + Apps Script)

इस पैकेज में पूरा JARVIS v2 Personal Assistant प्रोजेक्ट शामिल है।

## नए फ़ीचर्स (v2)
1. **कोई भी ऐप खोलना:** "WhatsApp खोलो", "YouTube चलाओ", "Instagram ओपन करो", "कैमरा खोलो"
2. **कॉल लगाना:** "राहुल को कॉल लगाओ", "9876543210 पर कॉल करो"
3. **अलार्म और टाइमर:** "सुबह 6:30 बजे का अलार्म लगाओ", "10 मिनट का टाइमर लगाओ"
4. **WhatsApp मैसेज:** "राहुल को WhatsApp करो कि मैं 10 मिनट में आ रहा हूँ"
5. **टॉर्च / फ्लैशलाइट:** "टॉर्च चालू करो", "फ्लैशलाइट बंद करो"
6. **YouTube / Google सर्च:** "YouTube पर अरिजीत सिंह के गाने चलाओ", "Google पर आज का मौसम खोजो"
7. **बोलना + टाइप करना:** माइक बटन के साथ नीचे टाइप करके कमांड भेजने का बॉक्स भी है।

## सेटअप स्टेप्स
1. `backend/Code.gs` का कोड Google Apps Script में पेस्ट करें, **Save** करें और **Manage deployments → Edit → New version → Deploy** करें।
2. बाकी Android प्रोजेक्ट को GitHub रिपॉज़िटरी में अनज़िप करके Push करें।
3. **Actions** टैब से `JARVIS-AI-v2-Debug-APK` डाउनलोड करके इंस्टॉल करें और Mic, Contacts व Phone की अनुमति दें।
