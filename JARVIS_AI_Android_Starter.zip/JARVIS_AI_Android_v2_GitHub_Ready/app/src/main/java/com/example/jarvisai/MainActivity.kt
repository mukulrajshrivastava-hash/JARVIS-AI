package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var speakButton: Button
    private lateinit var commandInput: EditText
    private lateinit var sendButton: Button

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val hindiLocale = Locale.forLanguageTag("hi-IN")

    private val backendUrl =
        "https://script.google.com/macros/s/AKfycbzzg0BuD2acMubOvEM8v2wLoc6CiW27vRhsiYCuH-_pzhG6-TnwVMXAuBRk4rr2-2ot/exec"

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(4, 12, 30)
        window.navigationBarColor = Color.rgb(4, 12, 30)

        tts = TextToSpeech(this, this)
        buildScreen()
        requestMissingPermissions()
    }

    private fun requestMissingPermissions() {
        val missing = requiredPermissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 100)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 40, 32, 28)
            setBackgroundColor(Color.rgb(4, 12, 30))
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(76, 210, 255))
        }

        val subtitle = TextView(this).apply {
            text = "PERSONAL AI ASSISTANT v2"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 86f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(65, 196, 255))
            setPadding(0, 14, 0, 10)
        }

        status = TextView(this).apply {
            text = "नमस्ते सर! मैं JARVIS हूँ।"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }

        transcript = TextView(this).apply {
            text = "बोलें: WhatsApp खोलो, कॉल लगाओ, अलार्म या टाइमर सेट करो, टॉर्च चालू करो..."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(175, 195, 215))
            setPadding(10, 18, 10, 18)
        }

        val scrollView = ScrollView(this).apply {
            isFillViewport = true
        }

        val contentBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        contentBox.addView(status, matchWrap())
        contentBox.addView(transcript, matchWrap())
        scrollView.addView(contentBox, matchWrap())

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 10, 0, 14)
        }

        val inputBg = GradientDrawable().apply {
            setColor(Color.rgb(15, 28, 56))
            cornerRadius = 24f
            setStroke(2, Color.rgb(45, 120, 175))
        }

        commandInput = EditText(this).apply {
            hint = "यहाँ कमांड लिखें..."
            setHintTextColor(Color.rgb(130, 150, 175))
            setTextColor(Color.WHITE)
            textSize = 15f
            background = inputBg
            setPadding(28, 20, 28, 20)
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    submitTypedCommand()
                    true
                } else {
                    false
                }
            }
        }

        val sendBg = GradientDrawable().apply {
            setColor(Color.rgb(22, 120, 185))
            cornerRadius = 24f
        }

        sendButton = Button(this).apply {
            text = "भेजें"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = sendBg
            setPadding(28, 18, 28, 18)
            setOnClickListener { submitTypedCommand() }
        }

        val inputParams = LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginEnd = 12
        }
        inputRow.addView(commandInput, inputParams)
        inputRow.addView(sendButton, LinearLayout.LayoutParams(-2, -2))

        val speakBg = GradientDrawable().apply {
            setColor(Color.rgb(30, 165, 225))
            cornerRadius = 30f
        }

        speakButton = Button(this).apply {
            text = "🎙 बोलें"
            textSize = 18f
            setTextColor(Color.WHITE)
            background = speakBg
            setPadding(24, 24, 24, 24)
            setOnClickListener { startListening() }
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(orb, matchWrap())
        root.addView(scrollView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(inputRow, matchWrap())
        root.addView(speakButton, matchWrap())

        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun submitTypedCommand() {
        val typed = commandInput.text.toString().trim()
        if (typed.isBlank()) return
        commandInput.setText("")
        tts?.stop()
        transcript.text = "आपने लिखा: $typed"
        respondTo(typed)
    }

    private fun setControlsEnabled(enabled: Boolean) {
        speakButton.isEnabled = enabled
        sendButton.isEnabled = enabled
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(
                this,
                "Speech Recognition उपलब्ध नहीं है।",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        tts?.stop()
        recognizer?.destroy()

        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    status.text = "सुन रहा हूँ..."
                    setControlsEnabled(false)
                }

                override fun onResults(results: Bundle?) {
                    setControlsEnabled(true)

                    val words = results?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )
                    val spoken = words?.firstOrNull().orEmpty().trim()

                    if (spoken.isBlank()) {
                        status.text = "कुछ सुनाई नहीं दिया।"
                        return
                    }

                    transcript.text = "आपने कहा: $spoken"
                    respondTo(spoken)
                }

                override fun onError(error: Int) {
                    setControlsEnabled(true)
                    status.text = "फिर से कोशिश करें"
                    transcript.text = "आवाज़ समझ नहीं आई।"
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS से हिंदी में बात करें")
        }

        recognizer?.startListening(intent)
    }

    private fun respondTo(input: String) {
        val q = input.lowercase(hindiLocale).trim()

        val instantAnswer = when {
            q == "नमस्ते" || q == "हेलो" || q == "hello" || q == "hi jarvis" ->
                "नमस्ते सर! बताइए, मैं आपकी क्या मदद करूँ?"

            q == "समय क्या हुआ है" || q == "टाइम क्या हुआ है" || q == "कितने बजे हैं" ->
                "अभी समय है " +
                    SimpleDateFormat("hh:mm a", hindiLocale).format(Date())

            q == "आज की तारीख क्या है" || q == "आज क्या तारीख है" ->
                "आज की तारीख " +
                    SimpleDateFormat("dd MMMM yyyy", hindiLocale).format(Date())

            else -> null
        }

        if (instantAnswer != null) {
            showAnswer(instantAnswer)
        } else {
            askGemini(input)
        }
    }

    private fun askGemini(question: String) {
        runOnUiThread {
            status.text = "JARVIS सोच रहा है..."
            setControlsEnabled(false)
        }

        executor.execute {
            var connection: HttpURLConnection? = null

            try {
                connection = URL(backendUrl)
                    .openConnection() as HttpURLConnection

                connection.instanceFollowRedirects = false
                connection.requestMethod = "POST"
                connection.connectTimeout = 20000
                connection.readTimeout = 60000
                connection.doOutput = true
                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=utf-8"
                )

                val request = JSONObject()
                    .put("message", question)
                    .toString()

                connection.outputStream.use {
                    it.write(request.toByteArray(Charsets.UTF_8))
                }

                var responseCode = connection.responseCode

                if (responseCode in 301..303) {
                    val redirectUrl = connection.getHeaderField("Location")
                    connection.disconnect()

                    if (redirectUrl.isNullOrBlank()) {
                        throw Exception("Redirect URL नहीं मिला।")
                    }

                    connection = URL(redirectUrl)
                        .openConnection() as HttpURLConnection
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 20000
                    connection.readTimeout = 60000
                    responseCode = connection.responseCode
                }

                val responseStream =
                    if (responseCode in 200..299) {
                        connection.inputStream
                    } else {
                        connection.errorStream
                    }

                val responseText = responseStream
                    ?.bufferedReader()
                    ?.use { it.readText() }
                    .orEmpty()
                    .trim()

                if (!responseText.startsWith("{")) {
                    throw Exception("बैकएंड से सही JSON नहीं मिला (HTTP $responseCode)।")
                }

                val json = JSONObject(responseText)
                val errorText = json.optString("error")
                if (errorText.isNotBlank()) {
                    showAnswer(errorText)
                    return@execute
                }

                runOnUiThread {
                    handleAssistantAction(json, question)
                }

            } catch (e: Exception) {
                showAnswer(
                    "माफ़ कीजिए सर, कनेक्शन में समस्या है। " +
                        (e.message ?: "")
                )
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun handleAssistantAction(json: JSONObject, originalQuery: String) {
        val action = json.optString("action", "chat").lowercase(Locale.US)
        val answer = json.optString("answer", "ठीक है सर।")

        when (action) {
            "open_app" -> {
                val appName = json.optString("app_name").trim()
                val opened = openAppByName(appName)
                if (opened) {
                    showAnswer(answer)
                } else {
                    showAnswer("माफ़ कीजिए सर, आपके फ़ोन में '$appName' ऐप नहीं मिला।")
                }
            }

            "call" -> {
                val contactName = json.optString("contact_name").trim()
                val contactAlt = json.optString("contact_alt").trim()
                val phoneNumber = json.optString("phone_number").trim()
                makePhoneCall(contactName, contactAlt, phoneNumber, originalQuery, answer)
            }

            "set_alarm" -> {
                val hour = json.optInt("hour", -1)
                val minute = json.optInt("minute", 0)
                val label = json.optString("message", "JARVIS Alarm")
                setAlarm(hour, minute, label, answer)
            }

            "set_timer" -> {
                val seconds = json.optInt("seconds", 0)
                val label = json.optString("message", "JARVIS Timer")
                setTimer(seconds, label, answer)
            }

            "whatsapp" -> {
                val contactName = json.optString("contact_name").trim()
                val contactAlt = json.optString("contact_alt").trim()
                val phoneNumber = json.optString("phone_number").trim()
                val message = json.optString("message").trim()
                sendWhatsAppMessage(contactName, contactAlt, phoneNumber, message, answer)
            }

            "flashlight" -> {
                val state = json.optString("state", "on").lowercase(Locale.US)
                val turnOn = state == "on" || state == "true" || state == "चालू"
                toggleFlashlight(turnOn, answer)
            }

            "youtube_search" -> {
                val query = json.optString("query").ifBlank { originalQuery }
                openYouTubeSearch(query, answer)
            }

            "google_search" -> {
                val query = json.optString("query").ifBlank { originalQuery }
                openGoogleSearch(query, answer)
            }

            else -> {
                showAnswer(answer)
            }
        }
    }

    private fun openAppByName(rawName: String): Boolean {
        val name = rawName.lowercase(Locale.US).trim()
        if (name.isBlank()) return false

        // सिस्टम ऐप्स के लिए डायरेक्ट इंटेंट
        when {
            name.contains("camera") || name.contains("कैमरा") -> {
                return tryStartIntent(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            }
            name.contains("setting") || name.contains("सेटिंग") -> {
                return tryStartIntent(Intent(Settings.ACTION_SETTINGS))
            }
            name.contains("dialer") || name == "phone" || name.contains("फ़ोन") -> {
                return tryStartIntent(Intent(Intent.ACTION_DIAL))
            }
        }

        // पॉपुलर ऐप्स के पैकेज नाम
        val packageCandidates: List<String> = when {
            name.contains("whatsapp business") -> listOf("com.whatsapp.w4b", "com.whatsapp")
            name.contains("whatsapp") || name.contains("व्हाट्सएप") -> listOf("com.whatsapp", "com.whatsapp.w4b")
            name.contains("youtube") || name.contains("यूट्यूब") -> listOf("com.google.android.youtube")
            name.contains("instagram") || name.contains("इंस्टाग्राम") -> listOf("com.instagram.android")
            name.contains("chrome") || name.contains("क्रोम") -> listOf("com.android.chrome")
            name.contains("maps") || name.contains("मैप") -> listOf("com.google.android.apps.maps")
            name.contains("gmail") || name.contains("जीमेल") -> listOf("com.google.android.gm")
            name.contains("telegram") -> listOf("org.telegram.messenger")
            name.contains("facebook") -> listOf("com.facebook.katana", "com.facebook.lite")
            name.contains("phonepe") -> listOf("com.phonepe.app")
            name.contains("paytm") -> listOf("net.one97.paytm")
            name.contains("gpay") || name.contains("google pay") -> listOf("com.google.android.apps.nbu.paisa.user")
            name.contains("play store") -> listOf("com.android.vending")
            name.contains("spotify") -> listOf("com.spotify.music")
            name.contains("calculator") || name.contains("कैलकुलेटर") -> listOf(
                "com.google.android.calculator",
                "com.android.bbkcalculator",
                "com.vivo.calculator",
                "com.sec.android.app.popupcalculator"
            )
            name.contains("gallery") || name.contains("गैलरी") || name.contains("photos") -> listOf(
                "com.vivo.gallery",
                "com.google.android.apps.photos",
                "com.android.gallery3d"
            )
            else -> emptyList()
        }

        for (pkg in packageCandidates) {
            val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                return true
            }
        }

        // फ़ोन में इंस्टॉल किसी भी ऐप को नाम से ढूँढें
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(
                mainIntent,
                PackageManager.ResolveInfoFlags.of(0L)
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(mainIntent, 0)
        }

        for (info in apps) {
            val label = info.loadLabel(packageManager).toString().lowercase(Locale.US)
            if (label == name || label.contains(name) || name.contains(label)) {
                val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                    return true
                }
            }
        }

        return false
    }

    private fun makePhoneCall(
        contactName: String,
        contactAlt: String,
        phoneNumber: String,
        originalQuery: String,
        answer: String
    ) {
        val directDigits = phoneNumber.replace(Regex("[^0-9+]"), "")
        var targetNumber: String? = if (directDigits.length >= 3) directDigits else null
        var matchedName = contactName

        if (targetNumber == null) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 100)
                showAnswer("सर, कॉन्टैक्ट ढूँढने के लिए पहले Contacts की अनुमति दें, फिर दोबारा बोलें।")
                return
            }

            val result = findContactNumber(listOf(contactName, contactAlt, originalQuery))
            if (result != null) {
                matchedName = result.first
                targetNumber = result.second
            }
        }

        if (targetNumber.isNullOrBlank()) {
            showAnswer("माफ़ कीजिए सर, कॉन्टैक्ट लिस्ट में '$contactName' नहीं मिला।")
            return
        }

        val hasCallPerm = checkSelfPermission(Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED

        val intentAction = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val callIntent = Intent(intentAction, Uri.parse("tel:$targetNumber")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (tryStartIntent(callIntent)) {
            val finalMsg = if (matchedName.isNotBlank()) {
                "ठीक है सर, $matchedName को कॉल लगा रहा हूँ।"
            } else {
                answer
            }
            showAnswer(finalMsg)
        } else {
            showAnswer("माफ़ कीजिए सर, कॉल लगाने में समस्या आई।")
        }
    }

    private fun findContactNumber(candidates: List<String>): Pair<String, String>? {
        val queries = candidates
            .map { it.trim().lowercase(Locale.US) }
            .filter { it.length >= 2 }

        if (queries.isEmpty()) return null

        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        var bestMatch: Pair<String, String>? = null

        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            null
        )?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

            while (cursor.moveToNext()) {
                val displayName = cursor.getString(nameIdx)?.trim().orEmpty()
                val number = cursor.getString(numIdx)?.trim().orEmpty()
                if (displayName.isBlank() || number.isBlank()) continue

                val lowerName = displayName.lowercase(Locale.US)

                for (q in queries) {
                    if (lowerName == q) {
                        return Pair(displayName, number)
                    }
                    if (bestMatch == null && (lowerName.contains(q) || q.contains(lowerName))) {
                        bestMatch = Pair(displayName, number)
                    }
                }
            }
        }

        return bestMatch
    }

    private fun setAlarm(hour: Int, minute: Int, label: String, answer: String) {
        if (hour !in 0..23 || minute !in 0..59) {
            showAnswer("सर, अलार्म का सही समय बताइए, जैसे सुबह 7 बजे।")
            return
        }

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "JARVIS Alarm" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (tryStartIntent(intent)) {
            showAnswer(answer)
        } else {
            showAnswer("माफ़ कीजिए सर, इस फ़ोन में अलार्म ऐप सेट नहीं हो सका।")
        }
    }

    private fun setTimer(seconds: Int, label: String, answer: String) {
        if (seconds <= 0) {
            showAnswer("सर, टाइमर का समय बताइए, जैसे 5 मिनट।")
            return
        }

        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "JARVIS Timer" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (tryStartIntent(intent)) {
            showAnswer(answer)
        } else {
            showAnswer("माफ़ कीजिए सर, टाइमर सेट करने में समस्या आई।")
        }
    }

    private fun sendWhatsAppMessage(
        contactName: String,
        contactAlt: String,
        phoneNumber: String,
        message: String,
        answer: String
    ) {
        var digits = phoneNumber.replace(Regex("[^0-9]"), "")

        if (digits.length < 7 && (contactName.isNotBlank() || contactAlt.isNotBlank())) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 100)
                showAnswer("सर, कॉन्टैक्ट ढूँढने के लिए पहले Contacts की अनुमति दें।")
                return
            }

            val found = findContactNumber(listOf(contactName, contactAlt))
            if (found != null) {
                digits = found.second.replace(Regex("[^0-9]"), "")
            }
        }

        if (digits.isBlank()) {
            if (openAppByName("whatsapp")) {
                showAnswer("सर, '$contactName' का नंबर नहीं मिला, मैंने WhatsApp खोल दिया है।")
            } else {
                showAnswer("माफ़ कीजिए सर, फ़ोन में WhatsApp नहीं मिला।")
            }
            return
        }

        // अगर 10 अंकों का भारतीय नंबर हो तो 91 जोड़ दें
        if (digits.length == 10) {
            digits = "91$digits"
        }

        val url = "https://api.whatsapp.com/send?phone=$digits&text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (tryStartIntent(intent)) {
            showAnswer(answer)
        } else {
            showAnswer("माफ़ कीजिए सर, WhatsApp खोलने में समस्या आई।")
        }
    }

    private fun toggleFlashlight(turnOn: Boolean, answer: String) {
        try {
            val cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
            var backFlashCameraId: String? = null

            for (id in cameraManager.cameraIdList) {
                val chars = cameraManager.getCameraCharacteristics(id)
                val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    backFlashCameraId = id
                    break
                }
            }

            if (backFlashCameraId == null) {
                showAnswer("माफ़ कीजिए सर, इस फ़ोन में फ्लैशलाइट उपलब्ध नहीं मिली।")
                return
            }

            cameraManager.setTorchMode(backFlashCameraId, turnOn)
            showAnswer(answer)
        } catch (e: Exception) {
            showAnswer("माफ़ कीजिए सर, टॉर्च कंट्रोल करने में समस्या आई।")
        }
    }

    private fun openYouTubeSearch(query: String, answer: String) {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        val ytIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.google.android.youtube")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (tryStartIntent(ytIntent) || tryStartIntent(fallbackIntent)) {
            showAnswer(answer)
        } else {
            showAnswer("माफ़ कीजिए सर, YouTube खोलने में समस्या आई।")
        }
    }

    private fun openGoogleSearch(query: String, answer: String) {
        val uri = Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (tryStartIntent(intent)) {
            showAnswer(answer)
        } else {
            showAnswer("माफ़ कीजिए सर, Google सर्च खोलने में समस्या आई।")
        }
    }

    private fun tryStartIntent(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun showAnswer(answer: String) {
        runOnUiThread {
            status.text = answer
            setControlsEnabled(true)
            tts?.speak(
                answer,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "jarvis_reply"
            )
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = hindiLocale
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            val denied = permissions.indices.any {
                grantResults.getOrNull(it) != PackageManager.PERMISSION_GRANTED
            }
            if (denied) {
                Toast.makeText(
                    this,
                    "सभी असिस्टेंट फ़ीचर्स के लिए Mic, Contacts और Phone अनुमति दें।",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
