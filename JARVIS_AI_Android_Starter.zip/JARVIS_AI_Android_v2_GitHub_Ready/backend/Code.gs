function doGet() {
  return ContentService
    .createTextOutput("JARVIS AI v2 Personal Assistant Backend Online")
    .setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  try {
    var apiKey = PropertiesService
      .getScriptProperties()
      .getProperty("GEMINI_API_KEY");

    if (!apiKey) {
      throw new Error("Gemini API Key not configured");
    }

    if (!e || !e.postData || !e.postData.contents) {
      throw new Error("Request body is missing");
    }

    var data = JSON.parse(e.postData.contents);
    var question = (data.message || "").toString().trim();

    if (!question) {
      throw new Error("Message is missing");
    }

    var nowIst = Utilities.formatDate(
      new Date(),
      "Asia/Kolkata",
      "yyyy-MM-dd HH:mm (EEEE)"
    );

    var systemPrompt = [
      "तुम JARVIS हो — यूज़र के स्मार्ट हिंदी Android Personal Assistant।",
      "वर्तमान समय (IST): " + nowIst,
      "यूज़र की बात समझो और हमेशा केवल शुद्ध JSON ऑब्जेक्ट (बिना markdown या अतिरिक्त टेक्स्ट के) लौटाओ।",
      "",
      "संभावित actions और उनके फ़ील्ड्स:",
      "1. ऐप खोलना: {\"action\":\"open_app\", \"app_name\":\"english app name जैसे whatsapp, whatsapp business, youtube, instagram, camera, settings, chrome, maps, gmail, calculator, gallery, phone, messages, phonepe, paytm, gpay, telegram, spotify\", \"answer\":\"ठीक है सर, ... खोल रहा हूँ।\"}",
      "2. कॉल लगाना: {\"action\":\"call\", \"contact_name\":\"अंग्रेज़ी अक्षरों में सबसे संभावित नाम जैसे Rahul, Mom, Papa, Ritesh\", \"contact_alt\":\"वैकल्पिक नाम जैसे Mummy, Maa, Bhai (अगर लागू हो)\", \"phone_number\":\"अगर यूज़र ने सीधे नंबर बोला हो तो सिर्फ़ अंक\", \"answer\":\"ठीक है सर, ... को कॉल लगा रहा हूँ।\"}",
      "3. अलार्म लगाना: {\"action\":\"set_alarm\", \"hour\":7, \"minute\":30, \"message\":\"JARVIS Alarm\", \"answer\":\"ठीक है सर, सुबह 7:30 बजे का अलार्म सेट कर रहा हूँ।\"} (hour हमेशा 24-hour फॉर्मेट 0-23 में रखें: शाम 7 बजे = 19, सुबह 7 बजे = 7)",
      "4. टाइमर लगाना: {\"action\":\"set_timer\", \"seconds\":600, \"message\":\"JARVIS Timer\", \"answer\":\"ठीक है सर, 10 मिनट का टाइमर लगा रहा हूँ।\"}",
      "5. WhatsApp मैसेज भेजना: {\"action\":\"whatsapp\", \"contact_name\":\"अंग्रेज़ी अक्षरों में नाम\", \"contact_alt\":\"वैकल्पिक नाम\", \"phone_number\":\"अगर नंबर बोला हो\", \"message\":\"मैसेज का टेक्स्ट\", \"answer\":\"ठीक है सर, ... के लिए WhatsApp मैसेज तैयार कर रहा हूँ।\"}",
      "6. टॉर्च / फ्लैशलाइट: {\"action\":\"flashlight\", \"state\":\"on या off\", \"answer\":\"ठीक है सर, टॉर्च चालू/बंद कर रहा हूँ।\"}",
      "7. YouTube पर सर्च/गाना: {\"action\":\"youtube_search\", \"query\":\"सर्च टेक्स्ट\", \"answer\":\"ठीक है सर, YouTube पर ... खोज रहा हूँ।\"}",
      "8. Google सर्च: {\"action\":\"google_search\", \"query\":\"सर्च टेक्स्ट\", \"answer\":\"ठीक है सर, Google पर ... खोज रहा हूँ।\"}",
      "9. सामान्य बातचीत / सवाल: {\"action\":\"chat\", \"answer\":\"हिंदी में छोटा, सटीक और मददगार जवाब (2-3 वाक्यों में)\"}",
      "",
      "नियम:",
      "- answer हमेशा सरल, विनम्र और प्राकृतिक हिंदी में हो।",
      "- अगर यूज़र सिर्फ़ 'WhatsApp खोलो' कहे तो action 'open_app' रखें। अगर किसी को मैसेज भेजने को कहे तो action 'whatsapp' रखें।",
      "- केवल वैध JSON ऑब्जेक्ट ही आउटपुट करें।"
    ].join("\n");

    var payload = {
      system_instruction: {
        parts: [{ text: systemPrompt }]
      },
      contents: [
        {
          parts: [{ text: question }]
        }
      ],
      generationConfig: {
        temperature: 0.3,
        responseMimeType: "application/json"
      }
    };

    var primaryModel = "gemini-3.5-flash-lite";
    var lastError = "";

    var firstAttempt = callGeminiModel(apiKey, primaryModel, payload);
    if (firstAttempt.code < 400) {
      var parsedFirst = parseActionResponse(extractAnswer(firstAttempt.result));
      if (parsedFirst) {
        parsedFirst.model = primaryModel;
        return jsonResponse(parsedFirst);
      }
    } else {
      lastError = firstAttempt.errorMessage;
    }

    var fallbacks = getAvailableModels(apiKey, primaryModel).slice(0, 5);
    for (var i = 0; i < fallbacks.length; i++) {
      var backupModel = fallbacks[i];
      var attempt = callGeminiModel(apiKey, backupModel, payload);
      if (attempt.code < 400) {
        var parsedBackup = parseActionResponse(extractAnswer(attempt.result));
        if (parsedBackup) {
          parsedBackup.model = backupModel;
          return jsonResponse(parsedBackup);
        }
      } else {
        lastError = attempt.errorMessage;
      }
    }

    throw new Error(
      "अभी Gemini सर्वर पर ज़्यादा लोड है, कृपया कुछ सेकंड बाद फिर कोशिश करें। (" +
        lastError +
        ")"
    );

  } catch (error) {
    return jsonResponse({
      action: "chat",
      error: error.message
    });
  }
}

function parseActionResponse(rawAnswer) {
  if (!rawAnswer) return null;

  var cleaned = rawAnswer
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  var startIdx = cleaned.indexOf("{");
  var endIdx = cleaned.lastIndexOf("}");
  if (startIdx !== -1 && endIdx > startIdx) {
    cleaned = cleaned.substring(startIdx, endIdx + 1);
  }

  try {
    var obj = JSON.parse(cleaned);
    if (!obj.action) obj.action = "chat";
    if (!obj.answer) obj.answer = "ठीक है सर, आदेश का पालन कर रहा हूँ।";
    return obj;
  } catch (err) {
    return {
      action: "chat",
      answer: rawAnswer
    };
  }
}

function callGeminiModel(apiKey, model, payload) {
  var url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    model +
    ":generateContent";

  var response = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    headers: {
      "x-goog-api-key": apiKey
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  });

  var code = response.getResponseCode();
  var rawText = response.getContentText();
  var result = {};

  try {
    result = JSON.parse(rawText);
  } catch (err) {
    result = { error: { message: rawText } };
  }

  var errorMessage =
    (result.error && result.error.message) || ("HTTP " + code);

  return {
    code: code,
    result: result,
    errorMessage: errorMessage
  };
}

function getAvailableModels(apiKey, skipModel) {
  var listUrl = "https://generativelanguage.googleapis.com/v1beta/models";
  var res = UrlFetchApp.fetch(listUrl, {
    method: "get",
    headers: {
      "x-goog-api-key": apiKey
    },
    muteHttpExceptions: true
  });

  if (res.getResponseCode() >= 400) {
    return [];
  }

  var data = JSON.parse(res.getContentText());
  var models = data.models || [];
  var flashLite = [];
  var flash = [];
  var others = [];

  models.forEach(function(m) {
    var name = (m.name || "").replace("models/", "");
    var methods = m.supportedGenerationMethods || [];

    if (methods.indexOf("generateContent") === -1) return;
    if (name === skipModel) return;
    if (name.indexOf("gemini") === -1) return;

    var lower = name.toLowerCase();
    if (
      lower.indexOf("embedding") !== -1 ||
      lower.indexOf("tts") !== -1 ||
      lower.indexOf("image") !== -1 ||
      lower.indexOf("audio") !== -1 ||
      lower.indexOf("vision") !== -1 ||
      lower.indexOf("veo") !== -1 ||
      lower.indexOf("aqa") !== -1 ||
      lower.indexOf("robotics") !== -1
    ) {
      return;
    }

    if (lower.indexOf("lite") !== -1) {
      flashLite.push(name);
    } else if (lower.indexOf("flash") !== -1) {
      flash.push(name);
    } else {
      others.push(name);
    }
  });

  flashLite.reverse();
  flash.reverse();
  others.reverse();

  return flashLite.concat(flash).concat(others);
}

function extractAnswer(result) {
  var answer = "";
  var parts =
    result &&
    result.candidates &&
    result.candidates[0] &&
    result.candidates[0].content &&
    result.candidates[0].content.parts;

  if (parts) {
    parts.forEach(function(part) {
      if (part.text && !part.thought) {
        answer += part.text;
      }
    });
  }

  return answer.trim();
}

function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function testGemini() {
  var fakeEvent = {
    postData: {
      contents: JSON.stringify({
        message: "सुबह 6:30 बजे का अलार्म लगा दो"
      })
    }
  };
  var response = doPost(fakeEvent);
  Logger.log(response.getContent());
}
