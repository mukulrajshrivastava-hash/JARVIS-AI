# JARVIS AI Android App (GitHub Actions Ready)

इस ज़िप में आपकी सभी सुधारी हुई फ़ाइलें और GitHub Actions से APK बिल्ड करने की वर्कफ़्लो फ़ाइल शामिल है।

## शामिल फ़ाइलें
- `settings.gradle.kts`
- `build.gradle.kts`
- `gradle.properties`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/example/jarvisai/MainActivity.kt`
- `.github/workflows/build.yml`

## GitHub से APK कैसे बनाएँ
1. GitHub पर एक नई रिपॉज़िटरी बनाएँ (जैसे `jarvis-ai-android`)।
2. सभी फ़ाइलें सही फ़ोल्डर स्ट्रक्चर के साथ अपलोड करें (या Codespaces में ज़िप अनज़िप करके push करें)।
3. ऊपर **Actions** टैब में जाएँ -> **Build JARVIS AI APK** पर क्लिक करें।
4. लगभग 2-3 मिनट में बिल्ड पूरा होने के बाद नीचे **Artifacts** सेक्शन में **JARVIS-AI-Debug-APK** पर टैप करके APK डाउनलोड करें।
5. डाउनलोड की गई ज़िप को अनज़िप करें और अंदर से `app-debug.apk` अपने फ़ोन में इंस्टॉल कर लें।
