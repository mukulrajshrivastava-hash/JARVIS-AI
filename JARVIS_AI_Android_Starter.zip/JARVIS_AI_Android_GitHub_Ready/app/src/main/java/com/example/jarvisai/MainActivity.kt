package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var speakButton: Button

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val hindiLocale = Locale.forLanguageTag("hi-IN")

    private val backendUrl =
        "https://script.google.com/macros/s/AKfycbzzg0BuD2acMubOvEM8v2wLoc6CiW27vRhsiYCuH-_pzhG6-TnwVMXAuBRk4rr2-2ot/exec"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(4, 12, 30)
        window.navigationBarColor = Color.rgb(4, 12, 30)

        tts = TextToSpeech(this, this)
        buildScreen()

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.RECORD_AUDIO), 100
            )
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(4, 12, 30))
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(76, 210, 255))
        }

        val subtitle = TextView(this).apply {
            text = "YOUR PERSONAL AI ASSISTANT"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        }

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 96f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(65, 196, 255))
            setPadding(0, 20, 0, 16)
        }

        status = TextView(this).apply {
            text = "नमस्ते! मैं JARVIS हूँ।"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }

        transcript = TextView(this).apply {
            text = "बात करने के लिए नीचे बटन दबाएँ।"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(190, 205, 220))
            setPadding(12, 20, 12, 20)
        }

        val scrollView = ScrollView(this).apply {
            isFillViewport = true
        }

        val contentBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        contentBox.addView(status, matchWrap())
        contentBox.addView(transcript, matchWrap())
        scrollView.addView(contentBox, matchWrap())

        speakButton = Button(this).apply {
            text = "🎙 बोलें"
            textSize = 18f
            setOnClickListener { startListening() }
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(orb, matchWrap())
        root.addView(scrollView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(speakButton, matchWrap())

        setContentView(root)
    }

    private fun matchWrap() =
        LinearLayout.LayoutParams(-1, -2)

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(
                this,
                "Speech Recognition उपलब्ध नहीं है।",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        tts?.stop()
        recognizer?.destroy()

        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {

                override fun onReadyForSpeech(params: Bundle?) {
                    status.text = "सुन रहा हूँ..."
                    speakButton.isEnabled = false
                }

                override fun onResults(results: Bundle?) {
                    speakButton.isEnabled = true

                    val words = results?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )
                    val spoken = words?.firstOrNull().orEmpty().trim()

                    if (spoken.isBlank()) {
                        status.text = "कुछ सुनाई नहीं दिया।"
                        return
                    }

                    transcript.text = "आपने कहा: $spoken"
                    respondTo(spoken)
                }

                override fun onError(error: Int) {
                    speakButton.isEnabled = true
                    status.text = "फिर से कोशिश करें"
                    transcript.text = "आवाज़ समझ नहीं आई।"
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS से हिंदी में बात करें")
        }

        recognizer?.startListening(intent)
    }

    private fun respondTo(input: String) {
        val q = input.lowercase(hindiLocale)

        val localAnswer = when {
            q == "नमस्ते" || q == "हेलो" || q == "hello" ->
                "नमस्ते! बताइए, मैं आपकी क्या मदद करूँ?"

            q.contains("समय") || q.contains("टाइम") || q.contains("कितने बजे") ->
                "अभी समय है " +
                    SimpleDateFormat("hh:mm a", hindiLocale).format(Date())

            q.contains("तारीख") || q.contains("date") || q.contains("आज कौन सा दिन") ->
                "आज की तारीख " +
                    SimpleDateFormat("dd MMMM yyyy", hindiLocale).format(Date())

            q.contains("तुम कौन") || q.contains("तुम्हारा नाम") ->
                "मेरा नाम JARVIS है। मैं आपका पर्सनल असिस्टेंट हूँ।"

            else -> null
        }

        if (localAnswer != null) {
            showAnswer(localAnswer)
        } else {
            askGemini(input)
        }
    }

    private fun askGemini(question: String) {
        runOnUiThread {
            status.text = "JARVIS सोच रहा है..."
            speakButton.isEnabled = false
        }

        executor.execute {
            var connection: HttpURLConnection? = null

            try {
                connection = URL(backendUrl)
                    .openConnection() as HttpURLConnection

                connection.instanceFollowRedirects = false
                connection.requestMethod = "POST"
                connection.connectTimeout = 20000
                connection.readTimeout = 60000
                connection.doOutput = true
                connection.setRequestProperty(
                    "Content-Type",
                    "application/json; charset=utf-8"
                )

                val request = JSONObject()
                    .put("message", question)
                    .toString()

                connection.outputStream.use {
                    it.write(request.toByteArray(Charsets.UTF_8))
                }

                var responseCode = connection.responseCode

                if (responseCode in 301..303) {
                    val redirectUrl = connection.getHeaderField("Location")
                    connection.disconnect()

                    if (redirectUrl.isNullOrBlank()) {
                        throw Exception("Redirect URL नहीं मिला।")
                    }

                    connection = URL(redirectUrl)
                        .openConnection() as HttpURLConnection
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 20000
                    connection.readTimeout = 60000
                    responseCode = connection.responseCode
                }

                val responseStream =
                    if (responseCode in 200..299) {
                        connection.inputStream
                    } else {
                        connection.errorStream
                    }

                val responseText = responseStream
                    ?.bufferedReader()
                    ?.use { it.readText() }
                    .orEmpty()
                    .trim()

                if (!responseText.startsWith("{")) {
                    throw Exception("बैकएंड से सही JSON नहीं मिला (HTTP $responseCode)।")
                }

                val json = JSONObject(responseText)
                val answer = json.optString("answer")

                if (answer.isNotBlank()) {
                    showAnswer(answer)
                } else {
                    val error = json.optString(
                        "error",
                        "Gemini से जवाब नहीं मिला।"
                    )
                    showAnswer(error)
                }

            } catch (e: Exception) {
                showAnswer(
                    "माफ कीजिए, AI कनेक्शन में समस्या है। " +
                        (e.message ?: "")
                )
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun showAnswer(answer: String) {
        runOnUiThread {
            status.text = answer
            speakButton.isEnabled = true
            tts?.speak(
                answer,
                TextToSpeech.QUEUE_FLUSH,
                null,
                "jarvis_reply"
            )
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = hindiLocale
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(
            requestCode, permissions, grantResults
        )

        if (requestCode == 100 &&
            (grantResults.isEmpty() ||
                grantResults[0] != PackageManager.PERMISSION_GRANTED)
        ) {
            Toast.makeText(
                this,
                "Microphone permission जरूरी है।",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
