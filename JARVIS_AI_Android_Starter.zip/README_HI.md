# JARVIS AI — Android Starter (Version 1.0)

यह Android Studio के लिए शुरुआती प्रोजेक्ट है।

## अभी क्या काम करता है
- डार्क, futuristic JARVIS होम स्क्रीन
- बटन दबाकर हिंदी में बोलना (Android Speech Recognition)
- हिंदी Text-to-Speech में जवाब
- शुरुआती लोकल कमांड: नमस्ते, समय, तारीख, नाम

## अभी क्या शामिल नहीं है
- ChatGPT/ऑनलाइन AI Brain
- हमेशा बैकग्राउंड में "Hey JARVIS" wake word
- कैमरा विज़न और दूसरे ऐप्स का नियंत्रण

इन फीचर्स के लिए अगले चरण में सुरक्षित AI backend, अतिरिक्त permissions और Android की background-service सीमाओं को ध्यान में रखकर काम करना होगा। API key को APK में सीधे नहीं रखना चाहिए।

## चलाने का तरीका
1. Android Studio में इस फ़ोल्डर को Open करें।
2. Gradle Sync पूरा होने दें।
3. Android फोन में Developer Options और USB Debugging चालू करें।
4. फोन कनेक्ट करके Run दबाएँ।
5. पहली बार Microphone permission Allow करें।

जरूरत: Android Studio का ऐसा संस्करण जो Android Gradle Plugin 8.7.3 और SDK 35 सपोर्ट करता हो।
