package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.provider.AlarmClock
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private val micRequest = 101
    private val contactsRequest = 102
    private val backendUrl = "https://script.google.com/macros/s/AKfycbzzg0BuD2acMubOvEM8v2wLoc6CiW27vRhsiYCuH-_pzhG6-TnwVMXAuBRk4rr-2-2ot/exec"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            setBackgroundColor(0xFF101820.toInt())
        }
        layout.addView(TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 30f
            setTextColor(0xFF00E5FF.toInt())
        })
        status = TextView(this).apply {
            text = "नमस्ते! मैं आपका पर्सनल असिस्टेंट हूँ।"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 32, 0, 32)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "🎙 बोलकर कमांड दें"
            setOnClickListener { listenNow() }
        })
        setContentView(layout)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    private fun speak(message: String) {
        runOnUiThread {
            status.text = message
            if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun listenNow() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS को कमांड दें")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, micRequest)
        } catch (_: Exception) {
            speak("इस फोन में Speech Recognition उपलब्ध नहीं है।")
        }
    }

    @Deprecated("Deprecated by Android; retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == micRequest && resultCode == Activity.RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (spoken.isNotBlank()) handleCommand(spoken.lowercase(Locale.ROOT))
        }
    }

    private fun handleCommand(raw: String) {
        val text = raw.replace("व्हाट्सएप", "whatsapp")
            .replace("व्हाट्सऐप", "whatsapp")
            .replace("यूट्यूब", "youtube")
            .replace("अलार्म", "alarm")
            .trim()
        when {
            text.contains("whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            text.contains("youtube") -> openApp("com.google.android.youtube", "YouTube")
            text.contains("alarm") || text.contains("अलार्म") -> parseAlarm(text)
            text.contains("call") || text.contains("कॉल") -> {
                val name = text.replace("call", "").replace("कॉल", "")
                    .replace("लगाओ", "").replace("करो", "").trim()
                if (name.isBlank()) speak("किसे कॉल करना है? नाम बताइए।")
                else findContactAndDial(name)
            }
            text.contains("समय") || text.contains("time") -> {
                val now = java.text.SimpleDateFormat("hh:mm a", Locale("hi", "IN")).format(java.util.Date())
                speak("अभी समय है $now")
            }
            else -> askBackend(raw)
        }
    }

    private fun openApp(packageName: String, appName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            speak("$appName खोल रहा हूँ।")
        } else if (appName == "YouTube") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
        } else speak("$appName आपके फोन में इंस्टॉल नहीं है।")
    }

    private fun parseAlarm(text: String) {
        val match = Regex("(\\\\d{1,2})(?::(\\\\d{2}))?\\\\s*(बजे|am|pm)?", RegexOption.IGNORE_CASE).find(text)
        if (match == null) {
            speak("कृपया समय अंकों में बताइए, जैसे सुबह 6 बजे अलार्म लगाओ।")
            return
        }
        var hour = match.groupValues[1].toIntOrNull() ?: -1
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        val suffix = match.groupValues[3].lowercase()
        if (hour !in 0..23 || minute !in 0..59) {
            speak("समय सही नहीं है। कृपया दोबारा बताइए।")
            return
        }
        if (suffix == "pm" && hour in 1..11) hour += 12
        if (suffix == "am" && hour == 12) hour = 0
        val alarm = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Alarm")
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        if (alarm.resolveActivity(packageManager) != null) {
            startActivity(alarm)
            speak("अलार्म सेट करने के लिए Clock खुल रहा है।")
        } else speak("इस फोन में Clock ऐप नहीं मिला।")
    }

    private fun findContactAndDial(name: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), contactsRequest)
            speak("कॉन्टैक्ट खोजने की अनुमति दीजिए, फिर कमांड दोबारा बोलिए।")
            return
        }
        try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val cursor = contentResolver.query(uri, projection, null, null, null)
            var number: String? = null
            cursor?.use {
                while (it.moveToNext()) {
                    val contactName = it.getString(0) ?: ""
                    if (contactName.contains(name, ignoreCase = true)) {
                        number = it.getString(1)
                        break
                    }
                }
            }
            if (number != null) {
                speak("$name का नंबर मिला। Dialer खोल रहा हूँ।")
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
            } else speak("कॉन्टैक्ट में $name नाम नहीं मिला।")
        } catch (_: Exception) {
            speak("कॉन्टैक्ट पढ़ने में समस्या आई।")
        }
    }

    private fun askBackend(question: String) {
        speak("सोच रहा हूँ, एक क्षण।")
        thread {
            try {
                val conn = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                conn.outputStream.use {
                    it.write(JSONObject().put("message", question).toString().toByteArray(Charsets.UTF_8))
                }
                val response = conn.inputStream.bufferedReader().use { it.readText() }
                val answer = JSONObject(response).optString("answer", "मुझे जवाब नहीं मिला।")
                conn.disconnect()
                speak(answer)
            } catch (_: Exception) {
                speak("अभी सर्वर से संपर्क नहीं हो पा रहा है। थोड़ी देर बाद कोशिश करें।")
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
