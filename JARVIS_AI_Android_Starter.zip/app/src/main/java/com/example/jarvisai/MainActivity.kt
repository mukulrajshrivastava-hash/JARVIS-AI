package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var speakButton: Button
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(4, 12, 30)
        window.navigationBarColor = android.graphics.Color.rgb(4, 12, 30)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(4, 12, 30))
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 34f
            letterSpacing = 0.18f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(76, 210, 255))
        }
        val subtitle = TextView(this).apply {
            text = "YOUR PERSONAL AI ASSISTANT"
            textSize = 11f
            letterSpacing = 0.16f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.LTGRAY)
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 112f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(65, 196, 255))
            setPadding(0, 35, 0, 25)
        }
        status = TextView(this).apply {
            text = "नमस्ते! मैं JARVIS हूँ।"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
        }
        transcript = TextView(this).apply {
            text = "बात करने के लिए नीचे बटन दबाएँ।"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(190, 205, 220))
            setPadding(12, 24, 12, 24)
        }
        speakButton = Button(this).apply {
            text = "🎙 बोलें"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        val footer = TextView(this).apply {
            text = "हिंदी वॉइस • शुरुआती संस्करण 1.0"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.GRAY)
            setPadding(0, 36, 0, 0)
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(orb, matchWrap())
        root.addView(status, matchWrap())
        root.addView(transcript, matchWrap())
        root.addView(speakButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(footer, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "इस डिवाइस पर Speech Recognition उपलब्ध नहीं है।", Toast.LENGTH_LONG).show()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    status.text = "सुन रहा हूँ…"
                    speakButton.isEnabled = false
                }
                override fun onResults(results: Bundle?) {
                    speakButton.isEnabled = true
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = words?.firstOrNull().orEmpty()
                    transcript.text = "आपने कहा: $spoken"
                    respondTo(spoken)
                }
                override fun onError(error: Int) {
                    speakButton.isEnabled = true
                    status.text = "फिर से कोशिश करें"
                    transcript.text = "आवाज़ समझ नहीं आई। कृपया दोबारा बोलें।"
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS से हिंदी में बात करें")
        }
        recognizer?.startListening(intent)
    }

    private fun respondTo(input: String) {
        val q = input.lowercase(Locale("hi", "IN"))
        val answer = when {
            q.contains("नमस्ते") || q.contains("हेलो") || q.contains("hello") ->
                "नमस्ते! बताइए, मैं आपकी क्या मदद करूँ?"
            q.contains("समय") || q.contains("टाइम") ->
                "अभी समय है " + java.text.SimpleDateFormat("hh:mm a", Locale("hi", "IN")).format(java.util.Date())
            q.contains("तारीख") || q.contains("आज") ->
                "आज की तारीख " + java.text.SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN")).format(java.util.Date())
            q.contains("तुम कौन") || q.contains("नाम") ->
                "मेरा नाम JARVIS है। मैं आपका पर्सनल असिस्टेंट हूँ।"
            else ->
                "मैंने आपकी बात सुनी। अभी मेरा AI Brain कनेक्ट नहीं है। अगले चरण में ऑनलाइन AI जोड़ा जाएगा।"
        }
        status.text = answer
        tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this, "Voice Assistant के लिए Microphone permission जरूरी है।", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
