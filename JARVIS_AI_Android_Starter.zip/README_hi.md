# JARVIS AI Personal Assistant V2

हिंदी voice input/reply, WhatsApp और YouTube खोलना, contact खोजकर Dialer खोलना,
Android Clock में alarm UI खोलना, तथा अन्य प्रश्न Apps Script backend को भेजना।

Repository root में `JARVIS_AI_Secure_Starter.zip` रखें। GitHub Actions इसे extract करके
debug APK बनाएगा। Debug build Play Protect certification नहीं है; सुरक्षा चेतावनी bypass न करें।
