private fun askBackend(question: String) {
    speak("सोच रहा हूँ, एक क्षण।")

    thread {
        var conn: HttpURLConnection? = null

        try {
            conn = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30000
                readTimeout = 60000
                doOutput = true
                instanceFollowRedirects = false

                setRequestProperty(
                    "Content-Type",
                    "application/json; charset=utf-8"
                )

                setRequestProperty(
                    "Accept",
                    "application/json"
                )
            }

            val requestBody = JSONObject()
                .put("message", question)
                .toString()

            conn.outputStream.use {
                it.write(requestBody.toByteArray(Charsets.UTF_8))
            }

            var code = conn.responseCode

            var responseText = ""

            // Google Apps Script Redirect संभालें
            if (code in 300..399) {

                val redirectUrl = conn.getHeaderField("Location")
                    ?: throw Exception("Redirect URL नहीं मिला")

                conn.disconnect()

                conn = (URL(redirectUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 30000
                    readTimeout = 60000
                }

                code = conn.responseCode
            }

            val stream = if (code in 200..299) {
                conn.inputStream
            } else {
                conn.errorStream
            }

            responseText = stream?.bufferedReader()?.use {
                it.readText()
            } ?: ""

            if (code !in 200..299) {
                throw Exception("HTTP $code: $responseText")
            }

            val json = JSONObject(responseText)

            val answer = json.optString(
                "answer",
                "मुझे जवाब नहीं मिला।"
            )

            if (answer.isBlank()) {
                throw Exception("Server से खाली जवाब मिला: $responseText")
            }

            speak(answer)

        } catch (e: Exception) {

            speak("सर्वर कनेक्शन में समस्या है: ${e.message}")

        } finally {
            conn?.disconnect()
        }
    }
}