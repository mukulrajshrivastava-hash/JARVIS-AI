# JARVIS AI Android Starter

यह एक साफ Android starter project है। इसमें केवल INTERNET और RECORD_AUDIO permissions हैं।
Gemini API key Android app में नहीं रखी गई है; वह Apps Script backend की Script Properties में ही रहनी चाहिए।

## Build
GitHub Actions workflow `android.yml` से Debug APK बनेगा। Debug APK परीक्षण के लिए है, Play Store release के लिए नहीं।

## ध्यान दें
- यह source code किसी APK के Play Protect scan में पास होने की गारंटी नहीं देता।
- Play Protect की चेतावनी को bypass न करें। यदि यह APK फिर harmful बताता है, इसे इंस्टॉल न करें।
- Apps Script backend को सुरक्षित रखें: request validation, rate limit और abuse protection जोड़ें।
- Backend को `{ "message": "..." }` स्वीकार करना और `{ "answer": "..." }` लौटाना चाहिए।
- Gemini API key को कभी Android source code या GitHub repository में न डालें।
